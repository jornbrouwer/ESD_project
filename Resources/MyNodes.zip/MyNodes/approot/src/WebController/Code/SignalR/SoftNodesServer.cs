﻿/*  MyNodes.NET 
    Copyright (C) 2016 Derwish <derwish.pro@gmail.com>
    License: http://www.gnu.org/licenses/gpl-3.0.txt  
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Infrastructure;
using MyNodes.Nodes;
using MyNodes.WebController.Controllers;


namespace MyNodes.WebController.Code
{
    public static class SoftNodesServer
    {
        //private static IHubContext hub;
        ////private static NodesEngine nodesEngine;

        //public static void Start(IConnectionManager connectionManager)
        //{
        //    hub = connectionManager.GetHubContext<SoftNodesHub>();
        //}

        



        //public static void Send(string value)
        //{
        //    hub.Clients.All.Send(value);
        //}
    }
}
