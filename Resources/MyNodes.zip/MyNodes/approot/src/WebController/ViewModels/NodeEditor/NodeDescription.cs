﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyNodes.WebController.ViewModels.NodeEditor
{
    public class NodeDescription
    {
        public string category;
        public string type;
        public string description;
    }
}
