You want to help out or ask a question? Great!!!

Minor things that make my life easier:

## Issues:
If you have a support question, asking it on [stackoverflow](http://stackoverflow.com/questions/tagged/nouislider) will get you an answer much faster.

## Pull requests:
- Please don't commit `/distribute/*` files, I'll do that upon release.
